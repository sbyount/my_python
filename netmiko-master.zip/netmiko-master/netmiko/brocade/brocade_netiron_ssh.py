from netmiko.cisco_base_connection import CiscoSSHConnection


class BrocadeNetironSSH(CiscoSSHConnection):
    pass
